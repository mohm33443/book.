const express =require('express');
const sqlite3 =require('sqlite3').verbose();
const app =express();
const port =process.env.PORT||3000;
app.use(express.json());

const db = new sqlite3.Database('./database/db.sqlite',(err)=>{

if(err){

    console.error('ERROR database connction '+err.message);

} else{
db.run (`CREATE TABLE IF NOT EXISTS users (
id INTEGER PRIMARY KEY AUTOINCREMENT,
username TEXT NOT NULL ,
password TEXT NOT NULL,
email TEXT NOT NULL UNIQUE,
Book name TEXT NOT NULL, 
Genre TEXT NOT NULL,
Author TEXT NOT NULL


  )`,(err)=>{
        if(err){
            console.error('ERROR in  user table creation '+ err.message);
        }else{
            console.log('users table created successfully');
        }
    });
}
console.log('connected to the database.');

});
// creat table

app.listen(port,()=>{
    console.log(`server is running on port ${port}`);
});